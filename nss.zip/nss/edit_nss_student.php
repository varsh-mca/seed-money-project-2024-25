f<?php
session_start();
include 'db_connection.php';

// Ensure the staff is logged in and has the appropriate role
if (!isset($_SESSION['staffid']) || $_SESSION['role'] !== 'nss_staff') {
    header("Location: staff_login.html");
    exit();
}

if (isset($_GET['id'])) {
    $student_id = $_GET['id'];
    $query = "SELECT * FROM nss_student WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if (!$student) {
        header("Location: show_nss_student.php");
        exit();
    }

    $departments_query = "SELECT department FROM departments";
    $departments_result = $conn->query($departments_query);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $rollno = $_POST['roll_no'];
        $name = $_POST['name'];
        $department = $_POST['department'];
        $class = $_POST['class'];

        // Update student data in nss_student table
        $update_query = "UPDATE nss_student SET rollno = ?, name = ?, department = ?, class = ? WHERE id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ssssi", $rollno, $name, $department, $class, $student_id);
        $stmt->execute();

        header("Location: show_nss_student.php");
        exit();
    }
} else {
    header("Location: show_nss_student.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #6dd5ed, #2193b0);
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 1.5s ease-in-out;
        }
        .container {
            width: 400px;
            background: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            text-align: center;
            animation: slideIn 1s ease-in-out;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            text-align: left;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
            font-size: 14px;
        }
        input, select {
            padding: 12px;
            margin-bottom: 20px;
            border: none;
            border-radius: 10px;
            background: #f1f1f1;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        input:focus, select:focus {
            outline: none;
            box-shadow: 0 0 10px rgba(33, 147, 176, 0.5);
            background: #eaf6f6;
        }
        button {
            padding: 14px;
            background: #2193b0;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            text-transform: uppercase;
            transition: background 0.3s ease;
        }
        button:hover {
            background: #6dd5ed;
        }
    </style>
</head>
<body>
<div class="container">
    <form method="POST">
        <label>Roll No</label>
        <input type="text" name="roll_no" value="<?php echo htmlspecialchars($student['rollno']); ?>" required>

        <label>Name</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($student['name']); ?>" required>

        <label>Class</label>
        <select name="class" required>
            <option value="I" <?php if ($student['class'] == 'I') echo 'selected'; ?>>I</option>
            <option value="II" <?php if ($student['class'] == 'II') echo 'selected'; ?>>II</option>
  <option value="III" <?php if ($student['class'] == 'III') echo 'selected'; ?>>III</option>
        </select>

        <label>Department Name</label>
        <select name="department" required>
            <?php while ($row = $departments_result->fetch_assoc()) { ?>
                <option value="<?= $row['department']; ?>" <?php if ($student['department'] == $row['department']) echo 'selected'; ?>><?= $row['department']; ?></option>
            <?php } ?>
        </select>

        <button type="submit">Update</button>
    </form>
</div>
</body>
</html>


