<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:\xampp\htdocs\seed\nss\vendor\phpmailer\phpmailer\src\Exception.php';
require 'C:\xampp\htdocs\seed\nss\vendor\phpmailer\phpmailer\src\PHPMailer.php';
require 'C:\xampp\htdocs\seed\nss\vendor\phpmailer\phpmailer\src\SMTP.php';

include "db_connection.php"; // Include database connection

session_start();
if (!isset($_SESSION['staffid'])) {
    die("Unauthorized access. Please log in.");
}

$staffid = $_SESSION['staffid']; // Get staff ID from session
$forum_name = "National Service Scheme"; // Default forum name
$message = $date = $time = $year = "";
$file_path = null;
$file_type = null;
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate required fields
    if (empty($_POST["message"])) {
        $errors[] = "Message is required.";
    } else {
        $message = trim($_POST["message"]);
    }

    if (empty($_POST["date"])) {
        $errors[] = "Date is required.";
    } else {
        $date = $_POST["date"];
    }

    if (empty($_POST["time"])) {
        $errors[] = "Time is required.";
    } else {
        $time = $_POST["time"];
    }

    if (empty($_POST["year"])) {
        $errors[] = "Year is required.";
    } else {
        $year = $_POST["year"];
    }

    // Handle file upload (optional)
    if (!empty($_FILES["file"]["name"])) {
        $target_dir = "uploads/"; // Ensure this directory exists
        $file_name = basename($_FILES["file"]["name"]);
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $file_path = $target_dir . time() . "_" . $file_name; // Unique file name

        $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'pdf'];

        if (!in_array($file_extension, $allowed_types)) {
            $errors[] = "Only JPG, JPEG, PNG, GIF, and PDF files are allowed.";
        } elseif ($_FILES["file"]["size"] > 5 * 1024 * 1024) { // 5MB max size
            $errors[] = "File size must be less than 5MB.";
        } else {
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $file_path)) {
                $file_type = ($file_extension === 'pdf') ? 'pdf' : 'image';
            } else {
                $errors[] = "Error uploading file.";
            }
        }
    }

    // Insert into database if no errors
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO nss_message (staffid, forum_name, message, image_path, date, time, year) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $staffid, $forum_name, $message, $file_path, $date, $time, $year);

        if ($stmt->execute()) {
            // Fetch student emails
            $email_stmt = $conn->prepare("SELECT email FROM nss_student WHERE year = ?");
            $email_stmt->bind_param("s", $year);
            $email_stmt->execute();
            $result = $email_stmt->get_result();

            $emails = [];
            while ($row = $result->fetch_assoc()) {
                $emails[] = $row['email'];
            }

            if (!empty($emails)) {
                sendEmailNotification($emails, $message, $date, $time, $forum_name, $file_path);
            }
            

            echo "<script>alert('Message posted successfully! Email notifications sent.');</script>";
        } else {
            echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
        }

        $stmt->close();
        $conn->close();
    }
}

// Function to send email notifications with file attachment
// Function to send email notifications with file attachment (sent once to all recipients)
function sendEmailNotification($recipients, $message, $date, $time, $forum_name, $file_path = null) {
    $mail = new PHPMailer(true);
    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP host
        $mail->SMTPAuth = true;
        $mail->Username = 'naveen9222777@gmail.com'; // Replace with your email
        $mail->Password = 'dvxb snoo mosq ntwn'; // Replace with your email password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Sender details
        $mail->setFrom('your-email@example.com', 'NSS Coordinator');

        // Add all recipients at once
        foreach ($recipients as $email) {
            $mail->addAddress($email);
        }

        // Email Content
        $mail->isHTML(true);
        $mail->Subject = "New NSS Announcement";
        $mail->Body = "<p>A new announcement has been posted in <strong>$forum_name</strong>.</p>
                       <p><strong>Message:</strong> $message</p>
                       <p><strong>Date:</strong> $date</p>
                       <p><strong>Time:</strong> $time</p>
                       <p>Please check the portal for more details.</p>";

        // Attach file if it exists
        if (!empty($file_path) && file_exists($file_path)) {
            $mail->addAttachment($file_path);
        }

        // Send the email once
        $mail->send();
        echo "<script>alert('Email sent successfully to all students.');</p>";
    } catch (Exception $e) {
        echo "<p style='color:red;'>Error sending email: {$mail->ErrorInfo}</p>";
    }
}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post a Message</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 50%;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: auto;
        }
        textarea, input {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .readonly-input {
            background-color: #e9ecef;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            margin-top: 10px;
        }
        button {
            background: #007BFF;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #0056b3;
        }
        .error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Post a Message</h2>

        <?php
        if (!empty($errors)) {
            echo '<div class="error">';
            foreach ($errors as $error) {
                echo "<p>$error</p>";
            }
            echo '</div>';
        }
        ?>

        <form action="" method="post" enctype="multipart/form-data">
            <label for="forum_name">Forum Name:</label>
            <input type="text" class="readonly-input" value="National Service Scheme" readonly>

            <br><br>

            <label for="message">Message:</label>
            <textarea name="message" required></textarea>

            <label for="date">Date:</label>
            <input type="date" name="date" required>

            <label for="time">Time:</label>
            <input type="time" name="time" required>

            <label for="year">Year:</label>
            <input type="number" name="year" min="1900" max="2099" required>

            <label for="file">Upload Image or PDF (Optional):</label>
            <input type="file" name="file" accept="image/*,application/pdf">

            <button type="submit">Submit</button>

        </form>
    </div>
 <center><b> <a href="dashboard_nss.php"> BACK  </a></b></center>
</body>
</html>
