<?php
// Database connection
include('db_connection.php'); // Make sure to include your database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form values
    $date = $_POST['date'];
    $event_name = $_POST['event_name'];
    $year = $_POST['year'];

    // If "Others" event is selected, use the custom event name
    if ($event_name == 'Others' && !empty($_POST['other_event_name'])) {
        $event_name = $_POST['other_event_name'];
    }

    // Query to fetch attendance data for the selected date, event, and year
    $query = "SELECT nss_attendance.rollno, nss_attendance.status, nss_student.name, nss_student.class, 
                     nss_student.department, nss_student.stream, nss_student.year 
              FROM nss_attendance
              INNER JOIN nss_student ON nss_attendance.rollno = nss_student.rollno
              WHERE nss_attendance.date = '$date' 
              AND nss_attendance.event_name = '$event_name' 
              AND nss_student.year = '$year'";
    $result = mysqli_query($conn, $query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Form</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #2c3e50;
        }

        .attendance-form label {
            font-size: 16px;
            color: #34495e;
        }

        .form-input, .form-select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 2px solid #bdc3c7;
            border-radius: 5px;
            font-size: 14px;
        }

        .submit-btn {
            width: 100%;
            padding: 12px;
            background-color: #2ecc71;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #27ae60;
        }

        table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #bdc3c7;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #2ecc71;
            color: white;
        }

        td {
            background-color: #ecf0f1;
        }

        .department-header {
            margin-top: 20px;
            font-size: 20px;
            color: #2c3e50;
            padding-bottom: 10px;
            border-bottom: 2px solid #bdc3c7;
        }

        .event-details {
            margin-top: 20px;
            font-size: 18px;
            color: #34495e;
            padding: 10px 0;
        }

        .other-event {
            display: none;
        }
    </style>
    <script>
        // JavaScript function to toggle the "Enter Event Name" field
        function toggleOtherField() {
            const eventNameSelect = document.getElementById('event_name');
            const otherEventDiv = document.getElementById('other_event');
            if (eventNameSelect.value === 'Others') {
                otherEventDiv.style.display = 'block';
            } else {
                otherEventDiv.style.display = 'none';
            }
        }
    </script>
</head>
<body>

<div class="container">

    <!-- Attendance form -->
    <form method="POST" action="" class="attendance-form">
        <h1>Attendance Form</h1>

        <label for="date">Date:</label>
        <input type="date" id="date" name="date" required class="form-input"><br><br>

        <label for="event_name">Event Name:</label>
        <select id="event_name" name="event_name" required class="form-select" onchange="toggleOtherField()">
            <option value="Regular Forum">Regular Forum</option>
            <option value="Others">Others</option>
        </select><br><br>

        <div id="other_event" class="other-event">
            <label for="other_event_name">Enter Event Name:</label>
            <input type="text" id="other_event_name" name="other_event_name" class="form-input"><br><br>
        </div>

        <label for="year">Year:</label>
        <input type="text" id="year" name="year" required class="form-input"><br><br>

        <input type="submit" name="show_students" value="Show Students" class="submit-btn">
    </form>

    <?php
    // Display event details
    if (isset($date) && isset($event_name) && isset($year)) {
        echo "<div class='event-details'>
                <p><strong>Event Name:</strong> $event_name</p>
                <p><strong>Date:</strong> $date</p>
                <p><strong>Year:</strong> $year</p>
              </div>";

        // If results are found, display the department-wise student list
        if (isset($result) && mysqli_num_rows($result) > 0) {
            $departments = [];

            while ($row = mysqli_fetch_assoc($result)) {
                $departments[$row['department']][] = $row;
            }

            // Display department-wise attendance
            foreach ($departments as $department => $students) {
                echo "<div class='department-header'> $department</div>";
                echo "<table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Roll No</th>
                                <th>Class</th>
                                <th>Stream</th>
                                <th>Year</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>";

                foreach ($students as $student) {
                    echo "<tr>
                            <td>{$student['name']}</td>
                            <td>{$student['rollno']}</td>
                            <td>{$student['class']}</td>
                            <td>{$student['stream']}</td>
                            <td>{$student['year']}</td>
                            <td>{$student['status']}</td>
                        </tr>";
                }

                echo "</tbody></table>";
            }
        } else {
            echo "<p>No attendance data found for this event.</p>";
        }
    }
    ?>

</div>

</body>
</html>
