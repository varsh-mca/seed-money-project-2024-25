<?php
session_start();
include 'db_connection.php'; // Include your database connection

// Check if staff is logged in and has the correct role
if (!isset($_SESSION['staffid']) || $_SESSION['role'] !== 'nss_staff') {
    header("Location: staff_login.html");
    exit();
}

$staffid = $_SESSION['staffid'];

// Fetch Staff Position
$query = "SELECT position FROM pe_staff WHERE staffid = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $staffid);
$stmt->execute();
$result = $stmt->get_result();
$position = 'Programme Officer';

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $position = $row['position'];
}
$stmt->close();

// Search Functionality
$search = "";
$search_query = "SELECT * FROM nss_student WHERE 1"; // Default query with WHERE 1 for flexible filtering
$params = [];
$types = "";

// If search input is provided
if (!empty($_GET['search'])) {
    $search = trim($_GET['search']);

    // Check if input is class ('I', 'II', 'III')
    if (in_array($search, ['I', 'II', 'III'])) {
        $search_query .= " AND class = ?";
        $params[] = $search;
        $types .= "s";
    } else {
        // Search by roll number, name, or department
        $search_query .= " AND (rollno LIKE ? OR name LIKE ? OR department LIKE ?)";
        $search_like = "%" . $search . "%";
        $params[] = $search_like;
        $params[] = $search_like;
        $params[] = $search_like;
        $types .= "sss";
    }
}

// Prepare the statement
$stmt_students = $conn->prepare($search_query);

// Bind parameters dynamically
if (!empty($params)) {
    $stmt_students->bind_param($types, ...$params);
}

$stmt_students->execute();
$students_result = $stmt_students->get_result();
$stmt_students->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pe Student Records</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f7f6;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            padding: 20px;
            background: #ffffff;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .search-box {
            text-align: right;
            margin-bottom: 20px;
        }

        input[type="text"] {
            padding: 10px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 20px;
            outline: none;
        }

        button {
            padding: 10px 20px;
            border: none;
            border-radius: 20px;
            background: #007bff;
            color: white;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background: #007bff;
            color: white;
        }

        tr:hover {
            background: #f1f1f1;
        }

        .btn {
            text-decoration: none;
            padding: 6px 12px;
            color: white;
            border-radius: 5px;
            margin: 0 5px;
        }

        .btn-edit {
            background: #28a745;
        }

        .btn-delete {
            background: #dc3545;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Physical Education Student Records</h1>

    <div class="search-box">
        <form method="GET">
            <input type="text" name="search" placeholder="Search by Roll No, Name, Department, or Class (I, II, III)..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">🔍 Search</button>
        </form>
    </div>

    <a href="add_nss_student.php" class="btn btn-edit">➕ Add New Student</a>

    <table>
        <thead>
            <tr>
                <th>Roll No</th>
                <th>Name</th>
                <th>Class</th>
                <th>Department</th>
                <th>Forum Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($students_result->num_rows > 0) { ?>
                <?php while ($student = $students_result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($student['rollno']); ?></td>
                        <td><?php echo htmlspecialchars($student['name']); ?></td>
                        <td><?php echo htmlspecialchars($student['class']); ?></td>
                        <td><?php echo htmlspecialchars($student['department']); ?></td>
                        <td><?php echo htmlspecialchars($student['forum_name']); ?></td>
                        <td>
                            <a href="edit_nss_student.php?id=<?php echo $student['id']; ?>" class="btn btn-edit">✏️ Edit</a>
                            <a href="delete_nss_student.php?id=<?php echo $student['id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this student?')">🗑️ Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr>
                    <td colspan="6" style="text-align: center; color: #999;">No records found</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>
<center><b><a href="dashboard_nss.php">Home</a></b></center>
<?php
$conn->close();
?>
