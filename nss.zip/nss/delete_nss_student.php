<?php
session_start();
include 'db_connection.php';

// Ensure the staff is logged in and has the appropriate role
if (!isset($_SESSION['staffid']) || $_SESSION['role'] !== 'nss_staff') {
    header("Location: staff_login.html");
    exit();
}


// Check if student ID is passed
if (isset($_GET['id'])) {
    $student_id = $_GET['id'];

    $student_rno = $_GET['rollno'];
    $query_rno = "SELECT * FROM student_data WHERE rollno = ?";
    $stmt_rno = $conn->prepare($query_rno);
    $stmt_rno->bind_param("s", $student_rno);
    $stmt_rno->execute();
    $result_rno = $stmt_rno->get_result();
    $student_rno = $result_rno->fetch_assoc();
    
    $session_rno = htmlspecialchars($student_rno['rollno']);

    // Delete the student from nss_student table
    $query = "DELETE FROM nss_student WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();

    // Also delete the student from student_data table
    $query = "DELETE FROM student_data WHERE rollno = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $session_rno);
    $stmt->execute();

    // Redirect back to the student list
    header("Location: show_nss_student.php");
    exit();
} else {
    header("Location: show_nss_student.php");
    exit();
}
?>
