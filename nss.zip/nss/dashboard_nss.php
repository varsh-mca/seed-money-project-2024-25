<?php
session_start();
include 'db_connection.php'; // Include database connection

// Ensure the staff is logged in
if (!isset($_SESSION['staffid'])) {
    header("Location: staff_login.html");
    exit();
}

$staffid = $_SESSION['staffid'];

// Check position from `nss_staff`
$query = "SELECT position FROM nss_staff WHERE staffid = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $staffid);
$stmt->execute();
$result = $stmt->get_result();

// Default position (to avoid undefined variables)
$position = null;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $position = $row['position'];
}
$stmt->close();

// If the user has no position, deny access
if (!$position) {
    echo "<script>alert('Access Denied! You are not registered in NSS.'); window.location.href='staff_login.html';</script>";
    exit();
}

// Fetch NSS students grouped by department for Programme Officer
$students_by_department = [];
if ($position === "Programme Officer") {
    $students_query = "SELECT rollno, name, class, department, forum_name FROM nss_students ORDER BY department";
    $students_result = $conn->query($students_query);
    
    while ($row = $students_result->fetch_assoc()) {
        $students_by_department[$row['department']][] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NSS Dashboard</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 12px;
            backdrop-filter: blur(10px);
            box-shadow: 0px 5px 20px rgba(0, 0, 0, 0.3);
            text-align: center;
            width: 80%;
            max-width: 800px;
        }
        h2, h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .btn {
            display: inline-block;
            padding: 12px 20px;
            margin: 10px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .btn-primary { background: #16a085; color: white; }
        .btn-primary:hover { background: #148f77; }
        .btn-success { background: #27ae60; color: white; }
        .btn-success:hover { background: #219150; }
        .btn-danger { background: #c0392b; color: white; }
        .btn-danger:hover { background: #a93226; }
        table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            overflow: hidden;
            color: white;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px;
            text-align: center;
        }
        th {
            background: rgba(255, 255, 255, 0.3);
        }
        tr:hover {
            background: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Welcome</h2>
        <p>Hello, <strong><?php echo htmlspecialchars($_SESSION['staffid']); ?></strong>! You have successfully logged in to the NSS Dashboard.</p>
        
        <a href="attendance_nss.php" class="btn btn-primary">Attendance</a>
        <a href="message_form_nss.php" class="btn btn-primary">Message</a>
        
        <?php if ($position === "National Service Scheme Coordinator"): ?>
            <p><strong>Position:</strong> National Service Scheme Coordinator</p>
            <a href="add_nss_student.php" class="btn btn-primary">Add Student</a>
            <a href="show_nss_student.php" class="btn btn-success">Show Students</a>
        
        <?php elseif ($position === "Programme Officer"): ?>
            <p><strong>Position:</strong> Programme Officer</p>
            
            <?php if (!empty($students_by_department)): ?>
                <?php foreach ($students_by_department as $department => $students): ?>
                    <h3><?php echo htmlspecialchars($department); ?></h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Roll Number</th>
                                <th>Name</th>
                                <th>Class</th>
                                <th>Forum Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student['rollno']); ?></td>
                                    <td><?php echo htmlspecialchars($student['name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['class']); ?></td>
                                    <td><?php echo htmlspecialchars($student['forum_name']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No NSS students registered yet.</p>
            <?php endif; ?>
        <?php else: ?>
            <p><strong>Position:</strong> <?php echo htmlspecialchars($position); ?></p>
        <?php endif; ?>
        
<a href="../logout.php" class="btn btn-danger">Logout</a>
    </div>
</body>
</html>