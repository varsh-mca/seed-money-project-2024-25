<?php
// Database Configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "seed_money";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$departments_result = $conn->query("SELECT department FROM departments");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $rollno = $_POST['rollno'];
    $gender = $_POST['gender'];
    $father_name = $_POST['father_name'];
    $mother_name = $_POST['mother_name'];
    $stream = $_POST['stream'];
    $year = $_POST['year'];
    $class = $_POST['class'];
    $department = $_POST['department'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $dob = $_POST['dob'];
    $forum_name = $_POST['forum_name'];
    $password = $_POST['password'];
    $community = $_POST['community'];
    $bloodgroup = $_POST['bloodgroup'];
    $talent = $_POST['talent'];
    $place = $_POST['place'];
    $date = $_POST['date'];

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO nss_student (name, rollno, gender, father_name, mother_name, stream, year, class, department, address, email, phone, dob, forum_name, password, community, bloodgroup, talent, place, date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssssssssssss", $name, $rollno, $gender, $father_name, $mother_name, $stream, $year, $class, $department, $address, $email, $phone, $dob, $forum_name, $hashed_password, $community, $bloodgroup, $talent, $place, $date);

    if ($stmt->execute()) {
        echo "<script>alert('Student Added Successfully');window.location='dashboard_nss.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }
        .form-container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #28a745;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
        }
        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Add Student</h2>
    <form action="" method="POST">
        <label>Name</label>
        <input type="text" name="name" required>

        <label>Roll Number</label>
        <input type="text" name="rollno" required>

        <label>Gender</label>
        <select name="gender" required>
            <option value="MALE">Male</option>
            <option value="FEMALE">Female</option>
        </select>

        <label>Father Name</label>
        <input type="text" name="father_name" required>

        <label>Mother Name</label>
        <input type="text" name="mother_name" required>

        <label>Stream</label>
        <select name="stream" required>
            <option value="AIDED">Aided</option>
            <option value="UNAIDED">Unaided</option>
        </select>

        <label>Year</label>
         <input type="text" name="year" required>

        <label>Class</label>
        <select name="class" required>
            <option value="I">I</option>
            <option value="II">II</option>
		 <option value="III">III</option>
        </select>

        <label>Department Name</label>
        <select name="department" required>
            <?php while ($row = $departments_result->fetch_assoc()) { ?>
                <option value="<?= $row['department']; ?>"><?= $row['department']; ?></option>
            <?php } ?>
        </select>

        <label>Address</label>
        <textarea name="address" required></textarea>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Phone</label>
        <input type="text" name="phone" required>

        <label>Date of Birth</label>
        <input type="date" name="dob" required>

        <label>Activity Name</label>
        <select name="forum_name" required>
            <option value="National Service Scheme">National Service Scheme</option>
                <option value="Youth Red Cross">Youth Red Cross</option>
                <option value="Social Service League">Social Service League</option>
                <option value="Citizen Consumer Club">Citizen Consumer Club</option>
                <option value="Environmental & Gardening Club">Environmental & Gardening Club</option>
                <option value="Physical Education">Physical Education</option>
                <option value="Blood Donors Club & Red Ribbon Club">Blood Donors Club & Red Ribbon Club</option>
                <option value="Clean Brigade">Clean Brigade</option>
                <option value="Gender Champions Club">Gender Champions Club</option>
                <option value="Rovers & Rangers">Rovers & Rangers</option>
                <option value="nss Drug Club">nss Drug Club</option>
                <option value="National Cadet Corps">National Cadet Corps</option>
        </select>

        <label>Password</label>
        <input type="password" name="password" required>

        <label>Community</label>
        <input type="text" name="community" required>

        <label>Blood Group</label>
        <input type="text" name="bloodgroup" required>

        <label>Talent</label>
        <textarea name="talent"></textarea>

        <label>Place</label>
        <input type="text" name="place" required>

        <label>Date</label>
        <input type="date" name="date" required>

        <button type="submit">Add Student</button>
    </form>
</div>
</body>
</html>
