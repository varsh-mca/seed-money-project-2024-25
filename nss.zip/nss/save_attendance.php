<?php
session_start();

include 'db_connection.php'; // Your database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_attendance'])) {
    $event_id = $_POST['event_id'];
    $date = $_POST['date'];
    $event_name = $_POST['event_name'];
    $year = $_POST['year'];
    $staffid = $_SESSION['staffid']; // Get staffid from session

    // Insert new attendance records
    if (isset($_POST['status'])) {
        foreach ($_POST['status'] as $rollno => $status) {
            $query = "INSERT INTO nss_attendance (event_id, rollno, name, department, class, event_name, date, year, status, staffid)
                      SELECT '$event_id', rollno, name, department, class, '$event_name', '$date', '$year', '$status', '$staffid' 
                      FROM nss_student WHERE rollno = '$rollno'";
            mysqli_query($conn, $query);
        }
    }

    // Update existing attendance records
    if (isset($_POST['update_status'])) {
        foreach ($_POST['update_status'] as $rollno => $status) {
            $query = "UPDATE nss_attendance SET status = '$status' WHERE event_id = '$event_id' AND rollno = '$rollno'";
            mysqli_query($conn, $query);
        }
    }

    echo "Attendance saved successfully!";
    header("Location: attendance_form.php?date=$date&event_name=$event_name&year=$year");
    exit();
}
