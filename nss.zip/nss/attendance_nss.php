<?php
// Include your database connection
include('db_connection.php');
session_start();

// Ensure staff is logged in
if (!isset($_SESSION['staffid'])) {
    die("Access Denied. Please log in.");
}

$staffid = $_SESSION['staffid']; // Get staffid from session
$successMessage = '';

// Handle "Show Students" Button
$show_students = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['show_students'])) {
    // Ensure values exist before using them
$date = isset($_POST['date']) ? $_POST['date'] : '';
$event_name = isset($_POST['event_name']) ? $_POST['event_name'] : '';
$year = isset($_POST['year']) ? $_POST['year'] : '';

if ($event_name == 'Others' && isset($_POST['other_event_name'])) {
    $event_name = $_POST['other_event_name'];
}


    $show_students = true;
}

// Handle "Save Attendance" Button
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_attendance'])) {
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $event_name = isset($_POST['event_name']) ? $_POST['event_name'] : '';
    $year = isset($_POST['year']) ? $_POST['year'] : '';

    if ($event_name == 'Others') {
        $event_name = $_POST['other_event_name'];
    }

    // Insert Event into `nss_event` table
    $event_query = "INSERT INTO nss_event (event_name, date, year, staffid) VALUES ('$event_name', '$date', '$year', '$staffid')";
    if (mysqli_query($conn, $event_query)) {
        $event_id = mysqli_insert_id($conn); // Get the inserted event ID

        // Fetch students
        $students_query = "SELECT rollno, name, department, class FROM nss_student WHERE year = '$year'";
        $students_result = mysqli_query($conn, $students_query);
        $attendanceSaved = false;

        while ($student = mysqli_fetch_assoc($students_result)) {
            $rollno = $student['rollno'];
            $name = $student['name'];
            $department = $student['department'];
            $class = $student['class'];

            // Check if present or absent checkbox is selected
            if (isset($_POST["present_$rollno"]) || isset($_POST["absent_$rollno"])) {
                $status = isset($_POST["present_$rollno"]) ? 'present' : 'absent';

                // Insert Attendance into `nss_attendance`
                $insert_query = "INSERT INTO nss_attendance (event_id, rollno, name, department, class, event_name, date, year, status, staffid) 
                                VALUES ('$event_id', '$rollno', '$name', '$department', '$class', '$event_name', '$date', '$year', '$status', '$staffid')";
                if (mysqli_query($conn, $insert_query)) {
                    $attendanceSaved = true;
                }
            }
        }

        // Display success message if attendance is saved
        if ($attendanceSaved) {
            $successMessage = 'Attendance has been successfully recorded!';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance for NSS Event</title>
    <style>
    * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f8f9fa;
    color: #343a40;
    line-height: 1.6;
    padding: 2rem;
}

.container {
    max-width: 1000px;
    margin: auto;
    padding: 1rem;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
}

h2, h3, h4 {
    text-align: center;
    margin-bottom: 1rem;
}

form {
    background: #fff;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
    margin-bottom: 2rem;
}

label {
    font-weight: bold;
    display: block;
    margin-bottom: 0.5rem;
}

input, select {
    width: 100%;
    padding: 0.8rem;
    border: 2px solid #dee2e6;
    border-radius: 8px;
    margin-bottom: 1rem;
    transition: all 0.3s ease;
}

input:focus, select:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 8px rgba(0, 123, 255, 0.2);
}

input[type="submit"] {
    background: linear-gradient(135deg, #007bff, #0062cc);
    color: white;
    border: none;
    padding: 0.8rem;
    cursor: pointer;
    font-size: 1rem;
    font-weight: bold;
    border-radius: 8px;
    transition: transform 0.2s ease;
    display: block;
    width: 100%;
    margin-top: 1rem;
}

input[type="submit"]:hover {
    transform: translateY(-2px);
}

/* Attendance Table Styling */
.student-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
    margin-top: 1rem;
}

.student-table th, .student-table td {
    padding: 1rem;
    text-align: left;
    border-right: 2px solid #343a40; /* Bold column separator */
}

.student-table th:last-child, .student-table td:last-child {
    border-right: none; /* Remove separator for the last column */
}

.student-table thead {
    background: linear-gradient(135deg, #007bff, #0062cc);
    color: white;
}

.student-table th {
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.9rem;
    border-bottom: 2px solid #343a40;
}

.student-table tbody tr {
    border-bottom: 2px solid #dee2e6; /* Light border between rows */
    transition: background-color 0.2s ease;
}

.student-table tbody tr:last-child {
    border-bottom: none;
}

.student-table td {
    text-align: center;
}

/* Checkboxes */
input[type="checkbox"] {
    transform: scale(1.3);
    margin: auto;
    cursor: pointer;
}

/* Department Header */
.department-header {
    background-color: #f1f1f1;
    font-weight: bold;
    text-align: center;
    padding: 1rem;
    font-size: 1.1rem;
    color: #333;
    margin-top: 1rem;
    border-radius: 5px;
}
</style>
</head>
<body>
    <div class="container">
        <h2>Attendance for NSS Event</h2>

        <form method="POST" action="attendance_nss.php" class="attendance-form">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required class="form-input"><br><br>

            <label for="event_name">Event Name:</label>
            <select id="event_name" name="event_name" required class="form-select" onchange="toggleOtherField()">
                <option value="Regular Forum">Regular Forum</option>
                <option value="Others">Others</option>
            </select><br><br>

            <div id="other_event" class="other-event" style="display: none;">
                <label for="other_event_name">Enter Event Name:</label>
                <input type="text" id="other_event_name" name="other_event_name" class="form-input"><br><br>
            </div>

            <label for="year">Student Joining Year:</label>
            <input type="text" id="year" name="year" required class="form-input"><br><br>

            <input type="submit" name="show_students" value="Show Students" class="submit-btn">
        </form>

        <hr>

        <h3>Attendance Table</h3>

        <?php
        // Display success message
        if (!empty($successMessage)) {
            echo "<p class='success-message'>$successMessage</p>";
        }

        if ($show_students) {
            $query = "SELECT name, rollno, class, department FROM nss_student WHERE year = '$year' ORDER BY department";
            $result = mysqli_query($conn, $query);

            // Organize students by department
            $students_by_department = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $students_by_department[$row['department']][] = $row;
            }

            // Display students department-wise
            echo "<form method='POST' action='attendance_nss.php' class='attendance-form'>";
            echo "<input type='hidden' name='date' value='$date'>";
            echo "<input type='hidden' name='event_name' value='$event_name'>";
            echo "<input type='hidden' name='year' value='$year'>";

            foreach ($students_by_department as $department => $students) {
                echo "<h4 class='department-header'>$department</h4>";
                echo "<table class='student-table'>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Roll No</th>
                                <th>Class</th>
                                <th>Present</th>
                                <th>Absent</th>
                            </tr>
                        </thead>
                        <tbody>";

                foreach ($students as $student) {
                    echo "<tr>
                            <td>{$student['name']}</td>
                            <td>{$student['rollno']}</td>
                            <td>{$student['class']}</td>
                            <td><input type='checkbox' name='present_{$student['rollno']}' value='present' class='attendance-checkbox'></td>
                            <td><input type='checkbox' name='absent_{$student['rollno']}' value='absent' class='attendance-checkbox'></td>
                        </tr>";
                }

                echo "</tbody></table><br>";
            }

            echo "<input type='submit' name='save_attendance' value='Save Attendance' class='submit-btn'>";
            echo "</form>";
        }
        ?>

        <script>
            function toggleOtherField() {
                var eventName = document.getElementById('event_name').value;
                document.getElementById('other_event').style.display = eventName === 'Others' ? 'block' : 'none';
            }
        </script>
		<center><table border="5" cellpadding="5" cellspacing=3"><tr><td><a href="dashboard_nss.php">HOME</a></tr></td></table></center>
    </div>
</body>
</html>
